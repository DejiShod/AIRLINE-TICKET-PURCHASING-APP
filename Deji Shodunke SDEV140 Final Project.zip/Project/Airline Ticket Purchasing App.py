"""This is an application that allows users to book flight tickets by first selecting the city/airport they will be departing from and then their arrival destination.  The user will also select the amount of 
passengers they are traveling with, the cabin experience, and then the amount of bags they will be checking in on this flight.  After all selections are made, the application will then produce a trip summary
displaying all selections from the user and the total amount due for the trip """


# tkinter GUI application creation.  PIL to support images for the application
import tkinter as tk
from tkinter import ttk
from PIL import Image, ImageTk


# define variables Origin, Destination, Passengers, Cabin and bags.
def origin(value):
    selectedLabel1.config(text=f"Selected: {value}")

def destination(value):
    selectedLabel2.config(text=f"Selected: {value}")
    
def passengers(value):
    selectedLabel3.config(text=f"Selected: {value}")

def cabin(value):
    selectedLabel4.config(text=f"Selected: {value}")

def bags(value):
    selectedLabel5.config(text=f"Selected: {value}")

# Exit application variable
def exitApplication():
    root.destroy()  

# Main application window named root.  This window will have an image, header, multiple labels and buttons to simplify the user experience.
root = tk.Tk()
root.title("AIRLINE TICKET PURCHASING APPLICATION")

# Root window image file path
imagePath = r"C:\Users\shoddeji\Documents\ERMC PC\MISC\Deji\Deji\2024\My Ivy\Software Development Technical Certificate\SDEV140\Project\plane1.png"
image = Image.open(imagePath)

maxWidth = 400
width, height = image.size
if width > maxWidth:
    newWidth = maxWidth
    newHeight = int((newWidth / width) * height)
    image = image.resize((newWidth, newHeight), Image.ANTIALIAS)

# Image object converted to a Tkinter PhotoImage object
tkImage = ImageTk.PhotoImage(image)

# Label widget to display the image
imageLabel = ttk.Label(root, image=tkImage)
imageLabel.pack(pady=15)  

titleLabel = tk.Label(root, text="BOOK FLIGHT TICKETS", font=("Helvetica", 20, "bold"))
titleLabel.pack(pady=20)  

# Variables buttonClick 1-6 to define selections Origin, Destination, Passengers, Cabin Experience, Bags & Submit
def buttonClick1():
    return

def buttonClick2():
    return

def buttonClick3():
    return

def buttonClick4():
    return

def buttonClick5():
    return

def buttonClick6():
    originVal = selectedOption1.get()
    destinationVal = selectedOption2.get()
    passengersVal = selectedOption3.get()
    cabinVal = selectedOption4.get()
    bagsVal = selectedOption5.get()
    seatPriceVal = 494
    taxesFeesVal = seatPriceVal * .098
    bagFeeVal = 0
    amountDueVal = 0
    
    #  Input Validation - First if statements that displays an error message in the main terminal if the origin and destination selected are the same
    #  Input Validation - Second if statement that displays an error message in the main terminal if a selection is left blank in the root application window 
    if originVal == destinationVal:
        tk.messagebox.showerror("Error", "Origin cannot be the same as destination.")
        return
    if not (originVal and destinationVal and passengersVal and cabinVal):
        tk.messagebox.showerror("Error", "Please select all options.")
        return


  # Seat Price Calculation based on cabin and number of passengers
    
    if cabinVal == "FIRST CLASS":
        seatPriceVal = seatPriceVal + (seatPriceVal * 1.002)   # 1.002% markup for first class
    
    if passengersVal.startswith("1"):
        seatPriceVal = seatPriceVal * 1
    elif passengersVal.startswith("2"):
        seatPriceVal = seatPriceVal * 2
    elif passengersVal.startswith("3"):
        seatPriceVal = seatPriceVal * 3
    elif passengersVal.startswith("4"):
        seatPriceVal = seatPriceVal * 4
    elif passengersVal.startswith("5"):
        seatPriceVal = seatPriceVal * 5
    elif passengersVal.startswith("6"):
        seatPriceVal = seatPriceVal * 6
    elif passengersVal.startswith("7"):
        seatPriceVal = seatPriceVal * 7
    elif passengersVal.startswith("8"):
        seatPriceVal = seatPriceVal * 8
    elif passengersVal.startswith("9"):
        seatPriceVal = seatPriceVal * 9
    
    # taxes and fees
    taxesFeesVal = seatPriceVal * .098
    
    bagFeeVal = 0
    if bagFeeVal == "1 bag":
        bagFeeVal = (35)
    
    if bagsVal == "1 Bag":
        bagFeeVal = 35
    elif bagsVal == "2 Bags":
        bagFeeVal = 35 + 45
    elif bagsVal == "3 Bags":
        bagFeeVal = 35 + 90
    elif bagsVal == "4 Bags":
        bagFeeVal = 35 + 135

    amountDueVal = seatPriceVal + taxesFeesVal + bagFeeVal
    
    # Callback to Flight Class
    flight = Flight(originVal, destinationVal, passengersVal, cabinVal, bagsVal, seatPriceVal, taxesFeesVal, bagFeeVal, amountDueVal)
    
    # Display flight details in a separate window
    displayResults(flight)
    
    # Second window defined to display trip summary and total costs.  window called resultsWindow
def displayResults(details):
    resultWindow = tk.Toplevel(root)
    resultWindow.title("FLIGHT DETAILS")
    
    # Second image for resultWindow
    imagePath1 = r"C:\Users\shoddeji\Documents\ERMC PC\MISC\Deji\Deji\2024\My Ivy\Software Development Technical Certificate\SDEV140\Project\airlineticket3.png"
    image = Image.open(imagePath1)

    maxWidth = 400
    width, height = image.size
    if width > maxWidth:
        newWidth = maxWidth
        newHeight = int((newWidth / width) * height)
        image = image.resize((newWidth, newHeight), Image.ANTIALIAS)

    # Image object converted to a Tkinter PhotoImage object
    global tkImageResult
    tkImageResult = ImageTk.PhotoImage(image)

    # Label widget created to display the image
    imageLabel = ttk.Label(resultWindow, image=tkImageResult)
    imageLabel.image = tkImageResult  
    imageLabel.pack(pady=20)  

    # Title for resultsWindow called Trip Summary
    titleLabel = tk.Label(resultWindow, text="TRIP SUMMARY", font=("Helvetica", 16, "bold"))
    titleLabel.pack(pady=20)  

    # Labels created to display results (origin, destination, passengers, cabin and bags)
    originLabel = tk.Label(resultWindow, text=f"Origin: {details.origin}")
    originLabel.pack()

    destinationLabel = tk.Label(resultWindow, text=f"Destination: {details.destination}")
    destinationLabel.pack()

    passengersLabel = tk.Label(resultWindow, text=f"Passengers: {details.passengers}")
    passengersLabel.pack()

    cabinLabel = tk.Label(resultWindow, text=f"Cabin: {details.cabin}")
    cabinLabel.pack()

    bagsLabel = tk.Label(resultWindow, text=f"Bags: {details.bags}")
    bagsLabel.pack()
    
    
    # Empty label used to create spacing between selections and cost calculations
     
    spaceLabel = tk.Label(resultWindow, text=" ")  # Create an empty label for spacing
    spaceLabel.pack()

    # Labels created to display calculations (Flights, Bag Fees, Taxes and Fees and Total amount Due.)  2f for 2 decimal spaces.
    seatPriceLabel = tk.Label(resultWindow, text=f"Flights: ${details.get_seatPrice():.2f}")
    seatPriceLabel.pack()
    
    bagFeesLabel = tk.Label(resultWindow, text=f"Bag Fees: ${details.get_bagFee():.2f}")
    bagFeesLabel.pack()
    
    taxesFeesLabel = tk.Label(resultWindow, text=f"Taxes, Fees & Charges: ${details.get_taxesFees():.2f}")
    taxesFeesLabel.pack()
    
    amountDueLabel = tk.Label(resultWindow, text=f"Amount Due: ${details.get_amountDue():.2f}")
    amountDueLabel.pack()



# Button for Passenger Origin Selection
button = ttk.Button(root, text="ORIGIN", command=buttonClick1)
button.pack(pady=20)

# Drop down menu that displays all options 
options1 = ["","BWI (Baltimore, MD)", "JFK (New York, NY)", "LAX (Los Angeles, CA)", "ATL (Atlanta, GA)", "LAS (Las Vegas, NV)", "MDW (Chicago-Midway, IL)", "MCO (Orlando, FL)", "DAL (Dallas-Love Field, TX)","SFO (San Francisco, CA)", "DEN (Denver, CO)"]
selectedOption1 = tk.StringVar(root)
selectedOption1.set(options1[0]) 

dropdown = ttk.Combobox(root, textvariable=selectedOption1, values=options1, state="readonly")
dropdown.pack(pady=10)
dropdown.bind("<<ComboboxSelected>>", lambda event: origin(selectedOption1.get()))

#Label to display final selection
selectedLabel1 = ttk.Label(root, text="Selected: ")
selectedLabel1.pack(pady=10)



# Button for Passenger Destination Selection
button = ttk.Button(root, text="DESTINATION", command=buttonClick2)
button.pack(pady=20)

options2 = ["","BWI (Baltimore, MD)", "JFK (New York, NY)", "LAX (Los Angeles, CA)", "ATL (Atlanta, GA)", "LAS (Las Vegas, NV)", "MDW (Chicago-Midway, IL)", "MCO (Orlando, FL)", "DAL (Dallas-Love Field, TX)","SFO (San Francisco, CA)", "DEN (Denver, CO)"]
selectedOption2 = tk.StringVar(root)
selectedOption2.set(options2[0])  # Set the default option

# Drop down menu that displays all options 
dropdown = ttk.Combobox(root, textvariable=selectedOption2, values=options2, state="readonly")
dropdown.pack(pady=10)
dropdown.bind("<<ComboboxSelected>>", lambda event: destination(selectedOption2.get()))

selectedLabel2 = ttk.Label(root, text="Selected: ")
selectedLabel2.pack(pady=10)



# Button for Number of Passengers Selection
button = ttk.Button(root, text="NUMBER OF PASSENGERS", command=buttonClick3)
button.pack(pady=20)

options3 = ["","1 Passenger", "2 Passengers", "3 Passengers", "4 Passengers", "5 Passengers", "6 Passengers", "7 Passengers", "8 Passengers", "9 Passengers"]
selectedOption3 = tk.StringVar(root)
selectedOption3.set(options3[0])  # Set the default option

dropdown = ttk.Combobox(root, textvariable=selectedOption3, values=options3, state="readonly")
dropdown.pack(pady=10)
dropdown.bind("<<ComboboxSelected>>", lambda event: passengers(selectedOption3.get()))

selectedLabel3 = ttk.Label(root, text="Selected: ")
selectedLabel3.pack(pady=10)



# Button for Type of Cabin Selection
button = ttk.Button(root, text="CABIN EXPERIENCE", command=buttonClick4)
button.pack(pady=20)

options4 = ["","ECONOMY", "FIRST CLASS"]
selectedOption4 = tk.StringVar(root)
selectedOption4.set(options4[0])  # Set the default option

dropdown = ttk.Combobox(root, textvariable=selectedOption4, values=options4, state="readonly")
dropdown.pack(pady=10)
dropdown.bind("<<ComboboxSelected>>", lambda event: cabin(selectedOption4.get()))

selectedLabel4 = ttk.Label(root, text="Selected: ")
selectedLabel4.pack(pady=10)



# Button for Type of Bag Selection
button = ttk.Button(root, text="BAGS", command=buttonClick5)
button.pack(pady=20)

options5 = ["","1 Bag","2 Bags","3 Bags","4 Bags"]
selectedOption5 = tk.StringVar(root)
selectedOption5.set(options5[0])  # Set the default option

dropdown = ttk.Combobox(root, textvariable=selectedOption5, values=options5, state="readonly")
dropdown.pack(pady=10)
dropdown.bind("<<ComboboxSelected>>", lambda event: bags(selectedOption5.get()))

selectedLabel5 = ttk.Label(root, text="Selected: ")
selectedLabel5.pack(pady=10)



# Button for Submit
button = ttk.Button(root, text="SUBMIT", command=buttonClick6)
button.pack(pady=20)

options6 = [","]
selectedOption6 = tk.StringVar(root)
selectedOption6.set(options6[0])  # Set the default option


# Button for Exit
button = ttk.Button(root, text="EXIT", command=exitApplication)
button.pack(pady=20)



#Flight Class created to establish (origin, destination, passengers, cabin, bags, seatPrice, taxesFees, bagFee and amountDue)
class Flight:
    def __init__(self, origin, destination, passengers, cabin, bags, seatPrice, taxesFees, bagFee, amountDue):
        self.origin = origin
        self.destination = destination
        self.passengers = passengers
        self.cabin = cabin
        self.bags = bags
        self.seatPrice = seatPrice
        self.taxesFees = taxesFees
        self.bagFee = bagFee
        self.amountDue = amountDue
        
    def get_origin(self):
        return self.origin
    
    def get_destination(self):
        return self.destination
    
    def get_passengers(self):
        return self.passengers
    
    def get_cabin(self):
        return self.cabin
    
    def get_bags(self):
        return self.bags
    
    def get_seatPrice(self):
        return self.seatPrice
    
    def get_bagFee(self):
        return self.bagFee
    
    def get_taxesFees(self):
        return self.taxesFees
    
    def get_amountDue(self):
        return self.amountDue
    
    def set_origin(self, origin):
        self.origin = origin
    
    def set_destination(self, destination):
        self.destination = destination
    
    def set_passengers(self, passengers):
        self.passengers = passengers
    
    def set_cabin(self, cabin):
        self.cabin = cabin
        
    def set_bags(self, bags):
        self.bags = bags
        
    def set_seatPrice(self, seatPrice):
        self.seatPrice = seatPrice
        
    def set_bagFee(self, bagFees):
        self.bagFees = bagFees

    def set_taxesFees(self, taxesFees):
        self.taxesFees = taxesFees
        
    def set_amountDue(self, amountDue):
        self.amountDue = amountDue



# Run the main event loop
root.mainloop()